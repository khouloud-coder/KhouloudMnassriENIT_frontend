import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RespirationsPage } from './respirations.page';

describe('RespirationsPage', () => {
  let component: RespirationsPage;
  let fixture: ComponentFixture<RespirationsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RespirationsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RespirationsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
