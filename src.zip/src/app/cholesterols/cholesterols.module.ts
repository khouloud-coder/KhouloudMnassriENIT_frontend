import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CholesterolsPageRoutingModule } from './cholesterols-routing.module';

import { CholesterolsPage } from './cholesterols.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CholesterolsPageRoutingModule
  ],
  declarations: [CholesterolsPage]
})
export class CholesterolsPageModule {}
