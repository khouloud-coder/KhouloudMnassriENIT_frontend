import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CholesterolsPage } from './cholesterols.page';

const routes: Routes = [
  {
    path: '',
    component: CholesterolsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CholesterolsPageRoutingModule {}
