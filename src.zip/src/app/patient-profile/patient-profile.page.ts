import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {PatientProfileService} from '../services/patient-profile.service';

@Component({
  selector: 'app-patient-profile',
  templateUrl: './patient-profile.page.html',
  styleUrls: ['./patient-profile.page.scss'],
})
export class PatientProfilePage implements OnInit {
    private dataProfile;
    private userProfile: number;
  constructor(private patientProfileService: PatientProfileService) { }

  ngOnInit() {
  }

  // onLoadProfile() {
  //    this.httpClient.post('http://127.0.0.1:8000/api/v1/users/<int:pk>/profile/');
  // }
    onLoadPatientProfile() {
    this.patientProfileService.getProfiledata(this.userProfile)
        .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
          this.dataProfile = data;
        }, err => {
          console.log(err);
        });
  }
}
