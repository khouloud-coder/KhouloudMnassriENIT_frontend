import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PatientProfilePageRoutingModule } from './patient-profile-routing.module';

import { PatientProfilePage } from './patient-profile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PatientProfilePageRoutingModule
  ],
  declarations: [PatientProfilePage]
})
export class PatientProfilePageModule {
  // public genders = [
  //   { val: 'male', isChecked: false },
  //   { val: 'female', isChecked: false },
  // ];
  // public bloodtypes = [
  //   { val: 'A+', isChecked: false },
  //   { val: 'A-', isChecked: false },
  //   { val: 'B+', isChecked: false },
  //   { val: 'B-', isChecked: false },
  //   { val: 'AB+', isChecked: false },
  //   { val: 'AB-', isChecked: false },
  //   { val: 'O+', isChecked: false },
  //   { val: 'O-', isChecked: false },
  // ];
}
