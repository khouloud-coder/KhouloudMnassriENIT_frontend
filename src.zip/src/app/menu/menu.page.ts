import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AuthenticationService} from '../services/authentication.service';
import {Patients1Page} from '../patients1/patients1.page';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {
  public menus = [
    {title: 'Home', url: '/menu/home'},
    {title: 'Patient Comments', url: '/menu/patient-comments'},
    {title: 'Patient Profile', url: '/menu/patient-profile'},
    {title: 'Patients', url: '/menu/patients'},
    {title: 'Respiratory Parameters', url: '/menu/respirations'},
    {title: 'Temperatures', url: '/menu/temperatures'},
    {title: 'Cholesterols', url: '/menu/cholesterols'},
    {title: 'Blood Pressures', url: '/menu/blood-pressures'},
    {title: 'Logout', url: 'logout'},
    {title: 'Patients1', url: '/menu/patients1'}
  ];

  constructor(private router: Router,
              private authService: AuthenticationService) { }

  ngOnInit() {
  }

  onMenuItem(m) {
    // tslint:disable-next-line:triple-equals
    if (m.url == 'logout'){
      this.authService.logout();
      this.router.navigateByUrl('/login');
    }
    else{
      this.router.navigateByUrl(m.url);
    }

  }
}
