import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MenuPageRoutingModule } from './menu-routing.module';

import { MenuPage } from './menu.page';
import {Route, RouterModule, Routes} from '@angular/router';
const routes: Routes = [
  {
    path: '',
    component: MenuPage,
    children: [
      {
        path: 'home',
        loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
      },
      {
        path: 'patients',
        loadChildren: () => import('../patients/patients.module').then( m => m.PatientsPageModule)
      },
      {
        path: 'patient-profile',
        loadChildren: () => import('../patient-profile/patient-profile.module').then( m => m.PatientProfilePageModule)
      },
      {
        path: 'patient-comments',
        loadChildren: () => import('../patient-comments/patient-comments.module').then( m => m.PatientCommentsPageModule)
      },
      {
        path: 'temperatures',
        loadChildren: () => import('../temperatures/temperatures.module').then( m => m.TemperaturesPageModule)
      },
      {
        path: 'cholesterols',
        loadChildren: () => import('../cholesterols/cholesterols.module').then( m => m.CholesterolsPageModule)
      },
      {
        path: 'blood-pressures',
        loadChildren: () => import('../blood-pressures/blood-pressures.module').then( m => m.BloodPressuresPageModule)
      },
      {
        path: 'respirations',
        loadChildren: () => import('../respirations/respirations.module').then( m => m.RespirationsPageModule)
      },
      {
        path: 'patients1',
        loadChildren: () => import('../patients1/patients1.module').then( m => m.Patients1PageModule)
      },
    ]
  },

];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
    // MenuPageRoutingModule
  ],
  declarations: [MenuPage]
})
export class MenuPageModule {}
