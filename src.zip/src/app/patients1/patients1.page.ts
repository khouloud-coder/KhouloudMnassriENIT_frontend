import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {Patient1Service, SearchType} from '../services/patient1.service';


@Component({
  selector: 'app-patients1',
  templateUrl: './patients1.page.html',
  styleUrls: ['./patients1.page.scss'],
})
export class Patients1Page implements OnInit {
  results: Observable<any>;
  searchTerm = '';
  type: SearchType = SearchType.all;

  constructor(private patient1Service: Patient1Service) { }

  ngOnInit() {
  }

  searchChanged($event: any) {
    // Call our service function which returns an Observable
    this.results = this.patient1Service.searchData(this.searchTerm, this.type);
  }

}
