import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Patients1Page } from './patients1.page';

const routes: Routes = [
  {
    path: '',
    component: Patients1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Patients1PageRoutingModule {}
