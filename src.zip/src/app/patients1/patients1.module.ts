import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Patients1PageRoutingModule } from './patients1-routing.module';

import { Patients1Page } from './patients1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Patients1PageRoutingModule
  ],
  declarations: [Patients1Page]
})
export class Patients1PageModule {}
