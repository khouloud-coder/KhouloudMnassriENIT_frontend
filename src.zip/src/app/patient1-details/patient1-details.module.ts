import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Patient1DetailsPageRoutingModule } from './patient1-details-routing.module';

import { Patient1DetailsPage } from './patient1-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Patient1DetailsPageRoutingModule
  ],
  declarations: [Patient1DetailsPage]
})
export class Patient1DetailsPageModule {}
