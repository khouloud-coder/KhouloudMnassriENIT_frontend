import { Patient1Service } from './../services/patient1.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-patient1-details',
  templateUrl: './patient1-details.page.html',
  styleUrls: ['./patient1-details.page.scss'],
})
export class Patient1DetailsPage implements OnInit {
  information = null;

  constructor(private activatedRoute: ActivatedRoute, private patient1Service: Patient1Service) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    this.patient1Service.getDetails(id).subscribe(result => {
      this.information = result;
    });
  }
  // openWebsite() {
  //   window.open(this.information.Website, '_blank');
  // }

}
