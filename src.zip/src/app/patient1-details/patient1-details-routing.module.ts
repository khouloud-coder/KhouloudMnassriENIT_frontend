import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Patient1DetailsPage } from './patient1-details.page';

const routes: Routes = [
  {
    path: '',
    component: Patient1DetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Patient1DetailsPageRoutingModule {}
