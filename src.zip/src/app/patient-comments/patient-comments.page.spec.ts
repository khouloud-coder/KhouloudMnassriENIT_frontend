import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PatientCommentsPage } from './patient-comments.page';

describe('PatientCommentsPage', () => {
  let component: PatientCommentsPage;
  let fixture: ComponentFixture<PatientCommentsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientCommentsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PatientCommentsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
