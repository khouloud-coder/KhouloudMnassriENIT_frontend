import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-comments',
  templateUrl: './patient-comments.page.html',
  styleUrls: ['./patient-comments.page.scss'],
})
export class PatientCommentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
