import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PatientCommentsPageRoutingModule } from './patient-comments-routing.module';

import { PatientCommentsPage } from './patient-comments.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PatientCommentsPageRoutingModule
  ],
  declarations: [PatientCommentsPage]
})
export class PatientCommentsPageModule {}
