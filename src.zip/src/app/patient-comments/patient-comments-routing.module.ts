import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PatientCommentsPage } from './patient-comments.page';

const routes: Routes = [
  {
    path: '',
    component: PatientCommentsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PatientCommentsPageRoutingModule {}
