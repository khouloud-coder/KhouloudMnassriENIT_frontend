import { Component, OnInit } from '@angular/core';
import {PatientTemperatureService} from '../services/patient-temperature.service';

@Component({
  selector: 'app-temperatures',
  templateUrl: './temperatures.page.html',
  styleUrls: ['./temperatures.page.scss'],
})
export class TemperaturesPage implements OnInit {
  private dataTemperature;
  private patientTemperature: number;

  constructor(private patientTemperatureService: PatientTemperatureService) { }

  ngOnInit() {
  }
  onLoadPatientTemperature() {
    this.patientTemperatureService.getTemperaturedata(this.patientTemperature)
        .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
          this.dataTemperature = data;
        }, err => {
          console.log(err);
        });
  }

}
