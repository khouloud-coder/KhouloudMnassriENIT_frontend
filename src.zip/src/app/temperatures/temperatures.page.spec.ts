import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TemperaturesPage } from './temperatures.page';

describe('TemperaturesPage', () => {
  let component: TemperaturesPage;
  let fixture: ComponentFixture<TemperaturesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemperaturesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TemperaturesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
