import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BloodPressuresPage } from './blood-pressures.page';

describe('BloodPressuresPage', () => {
  let component: BloodPressuresPage;
  let fixture: ComponentFixture<BloodPressuresPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BloodPressuresPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BloodPressuresPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
