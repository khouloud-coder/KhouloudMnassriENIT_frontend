import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BloodPressuresPage } from './blood-pressures.page';

const routes: Routes = [
  {
    path: '',
    component: BloodPressuresPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BloodPressuresPageRoutingModule {}
