import { TestBed } from '@angular/core/testing';

import { Patient1Service } from './patient1.service';

describe('Patient1Service', () => {
  let service: Patient1Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Patient1Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
