import { TestBed } from '@angular/core/testing';

import { PatientTemperatureService } from './patient-temperature.service';

describe('PatientTemperatureService', () => {
  let service: PatientTemperatureService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PatientTemperatureService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
