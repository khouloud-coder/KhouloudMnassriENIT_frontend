import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export enum SearchType {
  all = '',
  email = 'email',
}

@Injectable({
  providedIn: 'root'
})
export class Patient1Service {
  url = 'http://127.0.0.1:8000/api/v1/users/' ;
  // apiKey = '';

  constructor(private http: HttpClient) { }

  searchData(email: string, type: SearchType): Observable<any> {
    return this.http.get(`${this.url}?s=${encodeURI(email)}&type=${type}`).pipe(
        map(results => results)
    );
  }

  getDetails(id) {
    return this.http.get(`${this.url}?i=${id}&plot=full`);
  }
}
